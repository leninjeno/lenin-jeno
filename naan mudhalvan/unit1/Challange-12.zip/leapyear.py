
year = int(input('enter the year'))
if ((year % 4) == 0):
  print("leaf year")
else:
  print('its not leaf year')
year